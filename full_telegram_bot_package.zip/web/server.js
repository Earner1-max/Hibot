const express = require('express');
const multer = require('multer');
const fs = require('fs');
const path = require('path');
const { exec } = require('child_process');
const axios = require('axios');
const app = express();
const upload = multer({ dest: 'uploads/' });
const PORT = 3000;

app.use(express.static('public'));
app.use(express.json());

app.post('/announce', upload.any(), async (req, res) => {
  const message = req.body.message || '';
  const formData = new FormData();
  formData.append('message', message);
  if (req.files) {
    req.files.forEach(file => {
      formData.append('media', fs.createReadStream(file.path));
    });
  }
  try {
    await axios.post('http://telegram-bot-service/send-announcement', formData, {
      headers: formData.getHeaders()
    });
    res.send('✅ Announcement sent to bot.');
  } catch (err) {
    console.error(err);
    res.status(500).send('❌ Failed to send announcement.');
  }
});

app.post('/channels', (req, res) => {
  const { channels } = req.body;
  fs.writeFileSync('channels.txt', channels.join(','));
  res.send('✅ Channel list updated.');
});

app.post('/update-bot-code', upload.single('file'), (req, res) => {
  const filePath = path.join(__dirname, '../bot/main.py');
  fs.copyFileSync(req.file.path, filePath);
  exec('pkill -f main.py && python /app/main.py &');
  res.send('✅ Bot code updated and restarted.');
});

app.listen(PORT, () => console.log(`Admin Panel running at http://localhost:${PORT}`));
